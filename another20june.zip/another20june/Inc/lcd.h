#ifndef LCD_H
#define LCD_H

#include "stm32f4xx.h"

void LcdInit(void);
void lcd_command(uint8_t cmd);
void lcd_data(uint8_t data);
void lcd_print(uint8_t addr, char *str);

#endif
