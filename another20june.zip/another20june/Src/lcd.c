#include "lcd.h"
#include "stm32f4xx.h"

#define RS_PIN 0  // PA0
#define EN_PIN 1  // PA1

// D0–D7 mapping: PC4, PC5, PB0, PB1, PB12, PB13, PB14, PB15
void lcd_gpio_init(void) {
    // Enable clocks for GPIOA, GPIOB, GPIOC
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN | RCC_AHB1ENR_GPIOBEN | RCC_AHB1ENR_GPIOCEN;

    // RS and EN on PA0, PA1
    GPIOA->MODER &= ~((3 << (RS_PIN * 2)) | (3 << (EN_PIN * 2)));
    GPIOA->MODER |= ((1 << (RS_PIN * 2)) | (1 << (EN_PIN * 2)));

    // D0 and D1 on PC4, PC5
    GPIOC->MODER &= ~((3 << (4 * 2)) | (3 << (5 * 2)));
    GPIOC->MODER |= ((1 << (4 * 2)) | (1 << (5 * 2)));

    // D2, D3 on PB0, PB1
    GPIOB->MODER &= ~((3 << (0 * 2)) | (3 << (1 * 2)));
    GPIOB->MODER |= ((1 << (0 * 2)) | (1 << (1 * 2)));

    // D4–D7 on PB12–PB15
    for (int pin = 12; pin <= 15; pin++) {
        GPIOB->MODER &= ~(3 << (pin * 2));
        GPIOB->MODER |= (1 << (pin * 2));
    }
}

void delay(uint32_t ms) {
    for (uint32_t i = 0; i < ms * 16000; i++) __NOP();
}

void pulse_enable(void) {
    GPIOA->ODR |= (1 << EN_PIN);
    delay(1);
    GPIOA->ODR &= ~(1 << EN_PIN);
    delay(1);
}

void send_to_lcd(uint8_t byte, uint8_t is_data) {
    // RS = 0 for command, 1 for data
    if (is_data)
        GPIOA->ODR |= (1 << RS_PIN);
    else
        GPIOA->ODR &= ~(1 << RS_PIN);

    // D0 → PC4
    (byte & 0x01) ? (GPIOC->ODR |= (1 << 4)) : (GPIOC->ODR &= ~(1 << 4));
    // D1 → PC5
    (byte & 0x02) ? (GPIOC->ODR |= (1 << 5)) : (GPIOC->ODR &= ~(1 << 5));
    // D2 → PB0
    (byte & 0x04) ? (GPIOB->ODR |= (1 << 0)) : (GPIOB->ODR &= ~(1 << 0));
    // D3 → PB1
    (byte & 0x08) ? (GPIOB->ODR |= (1 << 1)) : (GPIOB->ODR &= ~(1 << 1));
    // D4 → PB12
    (byte & 0x10) ? (GPIOB->ODR |= (1 << 12)) : (GPIOB->ODR &= ~(1 << 12));
    // D5 → PB13
    (byte & 0x20) ? (GPIOB->ODR |= (1 << 13)) : (GPIOB->ODR &= ~(1 << 13));
    // D6 → PB14
    (byte & 0x40) ? (GPIOB->ODR |= (1 << 14)) : (GPIOB->ODR &= ~(1 << 14));
    // D7 → PB15
    (byte & 0x80) ? (GPIOB->ODR |= (1 << 15)) : (GPIOB->ODR &= ~(1 << 15));

    pulse_enable();
}

void lcd_command(uint8_t cmd) {
    send_to_lcd(cmd, 0);
    delay(2);
}

void lcd_data(uint8_t data) {
    send_to_lcd(data, 1);
    delay(2);
}

void LcdInit(void) {
    lcd_gpio_init();
    delay(40);

    lcd_command(0x38);  // 8-bit mode, 2 lines, 5x8 font
    lcd_command(0x0C);  // Display ON, cursor OFF
    lcd_command(0x01);  // Clear display
    delay(2);
    lcd_command(0x06);  // Entry mode: increment cursor
}

void lcd_print(uint8_t addr, char *str) {
    lcd_command(addr);
    while (*str) {
        lcd_data(*str++);
    }
}
